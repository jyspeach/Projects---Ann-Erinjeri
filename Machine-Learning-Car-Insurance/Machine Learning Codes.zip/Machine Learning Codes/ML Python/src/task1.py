import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
import numpy as np


#Loading the Dataset
def LoadData(FilePath):

    df = pd.read_csv(FilePath)
    global target_col
    target_col = "Response"
    global numeric_features, binary_features, categorical_features
    numeric_features = ["Age", "Annual_Premium", "Vintage"]
    binary_features = ["Driving_License", "Previously_Insured"]
    categorical_features = [
        "Gender",
        "Region_Code",
        "Vehicle_Age",
        "Vehicle_Damage",
        "Policy_Sales_Channel",
    ]
    global feature_cols
    feature_cols = numeric_features + binary_features + categorical_features
    global X, y
    X = df[feature_cols].copy()
    y = df[target_col].values
    global X_test, X_train, y_test, y_train
    #Train/test split on the data data (untransformed)
    X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

    print('Dataset Loaded. Split into training and testing set.')


    return df
    
#Reporting Data Exploratory Analysis 
def DataExploration(dataframe):
    if dataframe is None:
        print("Data not available.")
        return
    print("\nDataset Structure, Features, and Feature Types:") 
    print(dataframe.info()) #Shows the number of entries, the number and type of each feature in the dataset

    print("\nPercentage Breakdown for Response Variable:") #Percentage Breakdown for Response Variable
    print(f"\n{target_col} value distribution (%):")
    print((dataframe[target_col].value_counts(normalize=True) * 100).round(2).astype(str) + '%')

    print("\nSummary Statistics for Numerical Data:")
    print(dataframe[numeric_features].describe())  

    print("\nPercentage Breakdown for Categorical Data:") #Percentage Breakdown for Categorical Data
    for col in categorical_features:
        if col in dataframe.columns:
            print(f"\n{col} value distribution (%):")
            print((dataframe[col].value_counts(normalize=True) * 100).round(2).astype(str) + '%')

    print("\nPercentage Breakdown for Binary Data:") #Percentage Breakdown for Binary Data
    for col in binary_features:
        if col in dataframe.columns:
            print(f"\n{col} value distribution (%):")
            print((dataframe[col].value_counts(normalize=True) * 100).round(2).astype(str) + '%')

    print("\nMissing Values:") #Reports the number of missing values in each column
    print(dataframe.isnull().sum())
    print("\nDuplicate Rows:", dataframe.duplicated().sum()) #Reports the number of duplicate entries
    print("\nUnique Values per Column:") #Reports the number of unique values in each column
    print(dataframe.nunique())

def DataVisualization(df):
    if df is None:
        print("Data not available.")
        return


    custom_labels = {
        # Numerical
        "Age": "Age of the Policyholders",
        "Annual_Premium": "Premium Amount",
        "Vintage": "Number of Days the Customer Has Been Associated With the Company",

        # Binary
        "Driving_License": "Possession of a Driving License (0 = No, 1 = Yes)",
        "Previously_Insured": "Possession of Vehicle Insurance (1 = Has Insurance, 0 = Not Insured)",

        # Categorical
        "Gender": "Gender of Existing Policyholders",
        "Vehicle_Age": "Age of the Vehicle",
        "Vehicle_Damage": "Previous Damage to the Vehicle (0 = No, 1 = Yes)",
        "Region_Code": "Region Code",
        "Policy_Sales_Channel": "Policy Sales Channel Code",

        # Target
        "Response": "The Response Variable\n(0 = Does not buy insurance / 1 = Buys insurance)"
    }

    #Numeric Features Visualizations
    for col in numeric_features:
        plt.figure(figsize=(6, 4))
        sns.histplot(df[col], bins=30, kde=True, color="steelblue")
        plt.title(f"Distribution of {custom_labels[col]}")
        plt.xlabel(custom_labels[col])
        plt.ylabel("Count")
        plt.tight_layout()
        plt.show()

    #Binary Features Visualizations
    for col in binary_features:
        plt.figure(figsize=(5, 4))
        sns.countplot(x=col, data=df, palette="pastel")
        plt.title(f"Distribution of {custom_labels[col]}")
        plt.xlabel(custom_labels[col])
        plt.ylabel("Count")
        plt.tight_layout()
        plt.show()

    #Categorical Features Visualizations
    for col in categorical_features:
        plt.figure(figsize=(6, 4))

        if col == "Region_Code":
            top_regions = df[col].value_counts().nlargest(10).index
            sns.countplot(
                x=col,
                data=df[df[col].isin(top_regions)],
                palette="pastel"
            )
            plt.title(f"Distribution of Top 10 {custom_labels[col]}")
            plt.xticks(rotation=45)
        else:
            sns.countplot(x=col, data=df, palette="pastel")
            plt.title(f"Distribution of {custom_labels[col]}")

        plt.xlabel(custom_labels[col])
        plt.ylabel("Count")
        plt.tight_layout()
        plt.show()

    #Response vs. Numerical Features
    for col in numeric_features:
        plt.figure(figsize=(6, 4))
        sns.boxplot(x=target_col, y=col, data=df, palette="Set2")
        plt.title(f"{custom_labels[col]} vs Response")
        plt.xlabel(custom_labels["Response"])
        plt.ylabel(custom_labels[col])
        plt.tight_layout()
        plt.show()

    #Respons vs. Binary Features
    for col in binary_features:
        plt.figure(figsize=(5, 4))
        sns.countplot(x=col, hue=target_col, data=df, palette="Set2")
        plt.title(f"{custom_labels[col]} vs Response")
        plt.xlabel(custom_labels[col])
        plt.ylabel("Count")
        plt.tight_layout()
        plt.show()

    #Response vs. Categorical Features
    for col in categorical_features:
        plt.figure(figsize=(6, 4))

        if col == "Region_Code":
            sns.countplot(
                x=col,
                hue=target_col,
                data=df[df[col].isin(top_regions)],
                palette="Set2"
            )
            plt.title(f"Top 10 {custom_labels[col]} vs Response")
            plt.xticks(rotation=45)
        else:
            sns.countplot(x=col, hue=target_col, data=df, palette="Set2")
            plt.title(f"{custom_labels[col]} vs Response")

        plt.xlabel(custom_labels[col])
        plt.ylabel("Count")
        plt.tight_layout()
        plt.show()
    #Correlation between numeric features 
    plt.figure(figsize=(6, 4))
    sns.heatmap(df[numeric_features].corr(), annot=True, cmap="coolwarm")
    plt.title("Correlation Matrix (Numeric Features)")
    plt.show()





def DataEncoding_WithScaling():



    numeric_transformer = StandardScaler() #Define the ColumnTransformer
    categorical_transformer = OneHotEncoder(handle_unknown="ignore")


    preprocessor = ColumnTransformer( 
        transformers=[
            ("num", numeric_transformer, numeric_features + binary_features),
            ("cat", categorical_transformer, categorical_features),
        ]
    )
    # Fit the preprocessor on training set, then transform train and test
    X_train_scaled = preprocessor.fit_transform(X_train)
    X_test_scaled = preprocessor.transform(X_test)

    # Convert the data to with the kNN implemeted from scratch (the original transformation is optimised for scikit learn models)
    if not isinstance(X_train_scaled, np.ndarray):
        X_train_scaled = X_train_scaled.toarray()
    if not isinstance(X_test_scaled, np.ndarray):
        X_test_scaled = X_test_scaled.toarray()
    print("Transformed train shape:", X_train_scaled.shape)
    print("Transformed test shape:", X_test_scaled.shape)
    
    numeric_indices = preprocessor.transformers_[0][2]  # indices of numeric features

    print("Means:", X_train_scaled[:, :len(numeric_indices)].mean(axis=0)) #Verify that the means are approximately 0
    print("Standard Deviations:", X_train_scaled[:, :len(numeric_indices)].std(axis=0)) #Verify that the s.d. are  1


    # Return preprocessed data + preprocessor object
    return X_train_scaled, X_test_scaled, y_train, y_test, preprocessor


def DataEncoding():
    categorical_transformer = OneHotEncoder(handle_unknown="ignore")

    preprocessor = ColumnTransformer(
        transformers=[
            ("cat", categorical_transformer, categorical_features),
        ],
        remainder="passthrough"   # no scaling
    )

    X_train_trans = preprocessor.fit_transform(X_train)
    X_test_trans = preprocessor.transform(X_test)

    if not isinstance(X_train_trans, np.ndarray):
        X_train_trans = X_train_trans.toarray()
    if not isinstance(X_test_trans, np.ndarray):
        X_test_trans = X_test_trans.toarray()

    print("Raw transformed shapes:", X_train_trans.shape, X_test_trans.shape)

    return X_train_trans, X_test_trans, y_train, y_test, preprocessor