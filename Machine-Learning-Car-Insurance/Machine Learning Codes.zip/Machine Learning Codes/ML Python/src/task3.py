from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, confusion_matrix, classification_report
)
import numpy as np
import pandas as pd

def KNN_Scikit_Results(X_train, X_test, y_train, y_test, k_values):

    train_results = []   
    test_results = []    

    print("Results (KNN - Scikit Learn)\n")
    print("Running the model on selected k-values:")

    for k in k_values:

        knn_scikit = KNeighborsClassifier(n_neighbors=k)  # Euclidean distance by default 
        knn_scikit.fit(X_train, y_train)


        # Test predictions

        y_pred_test = knn_scikit.predict(X_test)

        # Train predictions 

        y_pred_train = knn_scikit.predict(X_train)


        # Test metrics

        test_acc = accuracy_score(y_test, y_pred_test)
        test_prec = precision_score(y_test, y_pred_test, zero_division=0)
        test_rec = recall_score(y_test, y_pred_test, zero_division=0)
        test_f1 = f1_score(y_test, y_pred_test, zero_division=0)


        # Train metrics 

        train_acc = accuracy_score(y_train, y_pred_train)
        train_prec = precision_score(y_train, y_pred_train, zero_division=0)
        train_rec = recall_score(y_train, y_pred_train, zero_division=0)
        train_f1 = f1_score(y_train, y_pred_train, zero_division=0)

        # Append trainingg metrics 
        train_results.append({
            "k": k,
            "accuracy": train_acc,
            "precision": train_prec,
            "recall": train_rec,
            "f1": train_f1
        })

        # Append testing metrics
        test_results.append({
            "k": k,
            "accuracy": test_acc,
            "precision": test_prec,
            "recall": test_rec,
            "f1": test_f1
        })

    

    train_df = pd.DataFrame(train_results)
    test_df = pd.DataFrame(test_results)

    print("\nTraining Performance Table:") #Showcasing training metrics
    print(train_df.to_string(index=False))

    print("\nTesting Performance Table:") #Showcasing testing metrics
    print(test_df.to_string(index=False))


    # Select best k by testing F1

    f1_scores = np.array([r['f1'] for r in test_results])
    best_idx = np.argmax(f1_scores)
    best_k = test_results[best_idx]['k']

    print("\nBest k based on F1:", best_k)

    # Train best model
    best_model = KNeighborsClassifier(n_neighbors=best_k)
    best_model.fit(X_train, y_train)
    y_pred_best = best_model.predict(X_test)

    print("\nConfusion Matrix:")
    print(confusion_matrix(y_test, y_pred_best))

    print("\nClassification Report:")
    print(classification_report(y_test, y_pred_best))

    return best_k, train_results, test_results
