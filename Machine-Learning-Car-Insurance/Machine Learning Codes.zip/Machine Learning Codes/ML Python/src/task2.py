import numpy as np
from collections import Counter
import pandas as pd
from sklearn.metrics import (
    confusion_matrix, 
    accuracy_score, 
    precision_score, 
    recall_score, 
    f1_score,
    classification_report
)

def euclidean_distance(x1, x2):  
    # Computes the Euclidean Distance between 2 samples.
    # Features with larger ranges influence the distance more.
    diff = x1 - x2              
    return np.sqrt(np.sum(diff * diff))

def majority_vote(labels):  
    # Returns the label that appears most in the list of neighbour labels
    votes = Counter(labels) 
    return votes.most_common(1)[0][0]

def KNN_predict_one(x, X_train, y_train, k):  
    # Applies the algorithm on one single test point 

    distances = []  # List of tuples containing distance and index of training sample 

    for i in range(len(X_train)):
        d = euclidean_distance(x, X_train[i])  # Calculates euclidean distance between the test point and each training sample
        distances.append((d, i))

    distances.sort(key=lambda t: t[0])  # Sorts them from nearest to farthest 

    k_nearest = distances[:k]  # Only selects the first k nearest neighbors

    neighbour_labels = [y_train[i] for (_, i) in k_nearest]  # Extracts labels based on index 

    return majority_vote(neighbour_labels)  # Returns the label with majority voting


def KNN_predict(X_test, X_train, y_train, k):  
    # Loops above function through each test sample 
    preds = []
    for x in X_test:
        label = KNN_predict_one(x, X_train, y_train, k)
        preds.append(label)
    return np.array(preds)


def KNN_Results(X_train, X_test, y_train, y_test, k_values):  
    # Evaluates kNN for list of k values 
    
    train_results = []   # table for training metrics
    test_results = []    # table for testing metrics

    print("Results (KNN - Manual Implementation)\n")
    
    for k in k_values:
        print(f"Running model for k = {k}")
        # Test set predictions
        y_pred_test = KNN_predict(X_test, X_train, y_train, k)

        # Train set predictions 
        
        y_pred_train = KNN_predict(X_train, X_train, y_train, k)

        # Test Metrics
        test_acc = accuracy_score(y_test, y_pred_test)  
        test_prec = precision_score(y_test, y_pred_test, zero_division=0)  
        test_rec = recall_score(y_test, y_pred_test, zero_division=0)  
        test_f1 = f1_score(y_test, y_pred_test, zero_division=0)  

        # Train Metrics 
        train_acc = accuracy_score(y_train, y_pred_train)
        train_prec = precision_score(y_train, y_pred_train, zero_division=0)
        train_rec = recall_score(y_train, y_pred_train, zero_division=0)
        train_f1 = f1_score(y_train, y_pred_train, zero_division=0)

        # Store training results 
        train_results.append({
            'k': k,
            'accuracy': train_acc,
            'precision': train_prec,
            'recall': train_rec,
            'f1': train_f1
        })

        # Store testing results
        test_results.append({
            'k': k,
            'accuracy': test_acc,
            'precision': test_prec,
            'recall': test_rec,
            'f1': test_f1
        })
    train_df =pd.DataFrame(train_results)
    test_df=pd.DataFrame(test_results)

    print("Training Performance Table:")
    print(train_df.to_string(index=False))

    print("\nTesting Performance Table:")
    print(test_df.to_string(index=False))

    # Select the best k based on testing F1 score
    test_f1_scores = np.array([row['f1'] for row in test_results])
    best_index = np.argmax(test_f1_scores)
    best_k = test_results[best_index]['k']

    print("Best k based on TEST F1-score:", best_k)

    # Final evaluation on the best k
    y_best_pred = KNN_predict(X_test, X_train, y_train, best_k)

    print("\nConfusion Matrix for best k:")  
    print(confusion_matrix(y_test, y_best_pred))

    print("\nClassification Report:")
    print(classification_report(y_test, y_best_pred))

    return best_k, train_df, test_df

