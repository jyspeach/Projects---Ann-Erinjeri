import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from imblearn.over_sampling import SMOTE
from collections import Counter
from sklearn.model_selection import cross_val_score
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, confusion_matrix, classification_report
)
import pandas as pd 
from sklearn.model_selection import train_test_split

#Class balancing using smote

def ClassBalancing(X_train_raw, y_train): 
    print("Before SMOTE:", Counter(y_train))

    sm = SMOTE(random_state=42)
    X_balanced, Y_balanced = sm.fit_resample(X_train_raw, y_train)

    print("After SMOTE:", Counter(Y_balanced))
    print(f"Balanced X shape: {X_balanced.shape}")
    print(f"Balanced y shape: {Y_balanced.shape}")

    minority_ratio_before = Counter(y_train)[1] / len(y_train)
    minority_ratio_after = Counter(Y_balanced)[1] / len(Y_balanced)

    print(f"Minority % before: {minority_ratio_before:.4f}")
    print(f"Minority % after:  {minority_ratio_after:.4f}")

    return X_balanced, Y_balanced

def ClassBalance_And_Scale(X_train_scaled, X_test_scaled, y_train): #Used for KNN

    #Balancing scaled data
    print("Before SMOTE:", Counter(y_train))

    sm = SMOTE(random_state=42)
    X_balanced_scaled, y_balanced = sm.fit_resample(X_train_scaled, y_train)

    print("After SMOTE:", Counter(y_balanced))
    print("Balanced shape:", X_balanced_scaled.shape)


    return X_balanced_scaled, X_test_scaled, y_balanced

#CROSS VALIDATION

def DecisionTree_WithCV(X_train, X_test, y_train, y_test, depths):

    train_rows, test_rows = [], []
    cv_scores = []

    print("Results (Decision Tree – Scikit + Cross-Validation)\n")

    for d in depths:

        dt = DecisionTreeClassifier(
            criterion="gini",
            max_depth=d,
            random_state=42
        )

        # 5-fold CV using F1
        cv_mean = cross_val_score(dt, X_train, y_train, cv=5, scoring="f1").mean()
        cv_scores.append(cv_mean)

        # Fit model on full training set
        dt.fit(X_train, y_train)

        # Predictions
        y_pred_test = dt.predict(X_test)
        y_pred_train = dt.predict(X_train)

        # Store Test Metrics
        test_rows.append({
            "Depth": d,
            "Accuracy": accuracy_score(y_test, y_pred_test),
            "Precision": precision_score(y_test, y_pred_test, zero_division=0),
            "Recall": recall_score(y_test, y_pred_test, zero_division=0),
            "F1": f1_score(y_test, y_pred_test, zero_division=0)
        })

        # Store Train Metrics
        train_rows.append({
            "Depth": d,
            "Accuracy": accuracy_score(y_train, y_pred_train),
            "Precision": precision_score(y_train, y_pred_train, zero_division=0),
            "Recall": recall_score(y_train, y_pred_train, zero_division=0),
            "F1": f1_score(y_train, y_pred_train, zero_division=0)
        })


    # Convert to DataFrames
    train_results = pd.DataFrame(train_rows)
    test_results = pd.DataFrame(test_rows)

    print("\nTraining Performance Table:")
    print(train_results.to_string(index=False))

    print("\nTesting Performance Table:")
    print(test_results.to_string(index=False))

    # Best depth chosen by CV-F1
    best_depth = depths[np.argmax(cv_scores)]
    print(f"\nBest depth based on Cross-Validated F1 = {best_depth}\n")

    # Final model using best depth
    best_dt = DecisionTreeClassifier(max_depth=best_depth, random_state=42)
    best_dt.fit(X_train, y_train)
    y_pred_final = best_dt.predict(X_test)

    print("\nConfusion Matrix (Best Depth):")
    print(confusion_matrix(y_test, y_pred_final))

    print("\nClassification Report (Best Depth):")
    print(classification_report(y_test, y_pred_final))

    return train_results, test_results, cv_scores, best_depth



def KNN_WithCV(X_train, X_test, y_train, y_test, k_values):

    train_rows = []
    test_rows = []
    cv_scores = []   # StoreS CV-F1 mean 

    print("Results (k-NN – Scikit + Cross-Validation)\n")
    print("Running model for selected k values...\n")

    for k in k_values:

        knn = KNeighborsClassifier(n_neighbors=k)

        # 5-Fold Cross-Validation 
        cv_mean = cross_val_score(knn, X_train, y_train, cv=5, scoring="f1").mean()
        cv_scores.append(cv_mean)


        knn.fit(X_train, y_train)

        # Predictions
        y_pred_test = knn.predict(X_test)
        y_pred_train = knn.predict(X_train)

        test_rows.append({
            "k": k,
            "Accuracy": accuracy_score(y_test, y_pred_test),
            "Precision": precision_score(y_test, y_pred_test, zero_division=0),
            "Recall": recall_score(y_test, y_pred_test, zero_division=0),
            "F1": f1_score(y_test, y_pred_test, zero_division=0)
        })


        train_rows.append({
            "k": k,
            "Accuracy": accuracy_score(y_train, y_pred_train),
            "Precision": precision_score(y_train, y_pred_train, zero_division=0),
            "Recall": recall_score(y_train, y_pred_train, zero_division=0),
            "F1": f1_score(y_train, y_pred_train, zero_division=0)
        })

    # Convert to DataFrame
    train_results = pd.DataFrame(train_rows)
    test_results  = pd.DataFrame(test_rows)

    print("\nTraining Performance Table:")
    print(train_results.to_string(index=False))

    print("\nTesting Performance Table:")
    print(test_results.to_string(index=False))

    #  selecting best k based on cv f1
    best_k = k_values[np.argmax(cv_scores)]
    print(f"\nBest k based on 5-fold CV F1 = {best_k}\n")

    
    best_knn = KNeighborsClassifier(n_neighbors=best_k)
    best_knn.fit(X_train, y_train)
    y_pred_final = best_knn.predict(X_test)

    print("\nConfusion Matrix (Best k):")
    print(confusion_matrix(y_test, y_pred_final))

    print("\nClassification Report (Best k):")
    print(classification_report(y_test, y_pred_final))

    return train_results, test_results, cv_scores, best_k

#FEATURE SELECTION

def evaluate_model(X, y, model_type, selected_features):
    # Extract only the selected columns
    X_sub = X[:, selected_features]

    # Split into train/validation
    X_train, X_val, y_train, y_val = train_test_split(
        X_sub, y, test_size=0.2, random_state=42, stratify=y
    )

    # Create model
    if model_type == "dt":
        model = DecisionTreeClassifier(max_depth=30, random_state=42)
    elif model_type == "knn":
        model = KNeighborsClassifier(n_neighbors=5)
    else:
        raise ValueError("model_type must be 'dt' or 'knn'")

    # Train
    model.fit(X_train, y_train)

    # Predict + Score (F1 because of imbalance)
    y_pred = model.predict(X_val)
    score = f1_score(y_val, y_pred, zero_division=0)

    return score
def forward_feature_selection(X, y, model_type):
    n_features = X.shape[1]

    selected_features = []
    remaining_features = list(range(n_features))

    best_overall_score = -np.inf
    improvement = True

    while improvement:
        improvement = False
        best_feature_this_round = None
        best_score_this_round = best_overall_score

        # Try adding each remaining feature
        for f in remaining_features:
            candidate_features = selected_features + [f]

            score = evaluate_model(X, y, model_type, candidate_features)

            if score > best_score_this_round:
                best_score_this_round = score
                best_feature_this_round = f

        # If improvement, update lists
        if best_feature_this_round is not None and best_score_this_round > best_overall_score:
            selected_features.append(best_feature_this_round)
            remaining_features.remove(best_feature_this_round)
            best_overall_score = best_score_this_round
            improvement = True
        else:
            improvement = False

    return selected_features, best_overall_score

def train_selected_DT_FS(X, y, selected_features, depth=10):
    X_sub = X[:, selected_features]

    X_train, X_test, y_train, y_test = train_test_split(
        X_sub, y, test_size=0.2, random_state=42, stratify=y
    )

    dt = DecisionTreeClassifier(max_depth=depth, random_state=42)
    dt.fit(X_train, y_train)
    y_pred = dt.predict(X_test)

    print("\nDecision Tree Final Model (Selected Features)")
    print("Selected Features:", selected_features)
    print("\nConfusion Matrix:")
    print(confusion_matrix(y_test, y_pred))
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

    return dt

def train_final_model(
    X_train, X_test, y_train, y_test,
    selected_features, model_type, model_hyperparams, feature_names
):
    

    # Selected feature names
    selected_feature_names = [feature_names[i] for i in selected_features]

    # Get data for the features 
    X_train_sub = X_train[:, selected_features]
    X_test_sub  = X_test[:, selected_features]

    # Build model
    if model_type == "dt":
        model = DecisionTreeClassifier(**model_hyperparams, random_state=42)

    elif model_type == "knn":
        model = KNeighborsClassifier(**model_hyperparams)

    else:
        raise ValueError("model_type must be 'dt' or 'knn'")

    # Train
    model.fit(X_train_sub, y_train)

    # Predictions
    preds_train = model.predict(X_train_sub)
    preds_test  = model.predict(X_test_sub)

    print("\n FINAL MODEL with SELECTED FEATURES")
    print("Selected Features:", selected_feature_names)

    # Train metrics
    print("\n TRAINING METRICS")
    print("Accuracy:", accuracy_score(y_train, preds_train))
    print("Precision:", precision_score(y_train, preds_train, zero_division=0))
    print("Recall:", recall_score(y_train, preds_train, zero_division=0))
    print("F1-score:", f1_score(y_train, preds_train, zero_division=0))

    # Test metrics
    print("\nTESTING METRICS ")
    print("Accuracy:", accuracy_score(y_test, preds_test))
    print("Precision:", precision_score(y_test, preds_test, zero_division=0))
    print("Recall:", recall_score(y_test, preds_test, zero_division=0))
    print("F1-score:", f1_score(y_test, preds_test, zero_division=0))

   
    print("\nConfusion Matrix:")
    print(confusion_matrix(y_test, preds_test))

    print("\nClassification Report:")
    print(classification_report(y_test, preds_test))

    return model

