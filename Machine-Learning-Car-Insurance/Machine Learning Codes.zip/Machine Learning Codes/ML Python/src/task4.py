from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import confusion_matrix, classification_report, f1_score, accuracy_score, precision_score, recall_score
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
def DecisionTree_Results(X_train, X_test, y_train, y_test, depths, feature_names):

    train_rows = [] #stores training metrics
    test_rows = [] #stores testing metrics
    importance_rows = [] #stores feature importance values

    print("Results (Decision Tree – Scikit)")

    for d in depths:
        dt = DecisionTreeClassifier(criterion="gini", max_depth=d, random_state=42) #Gini better on imbalanced datasets
        dt.fit(X_train, y_train)

        y_pred = dt.predict(X_test)
        y_pred_train = dt.predict(X_train)

        test_acc = accuracy_score(y_test, y_pred)
        test_prec = precision_score(y_test, y_pred, zero_division=0)
        test_rec = recall_score(y_test, y_pred, zero_division=0)
        test_f1 = f1_score(y_test, y_pred, zero_division=0)

        train_acc = accuracy_score(y_train, y_pred_train)
        train_prec = precision_score(y_train, y_pred_train, zero_division=0)
        train_rec = recall_score(y_train, y_pred_train, zero_division=0)
        train_f1 = f1_score(y_train, y_pred_train, zero_division=0)

        fi = dict(zip(feature_names, dt.feature_importances_))

        test_rows.append({
            "Depth": d,
            "Accuracy": test_acc,
            "Precision": test_prec,
            "Recall": test_rec,
            "F1": test_f1
        })

        train_rows.append({
            "Depth": d,
            "Accuracy": train_acc,
            "Precision": train_prec,
            "Recall": train_rec,
            "F1": train_f1
        })

        importance_rows.append({
            "Depth": d,
            "Feature_Importance": fi
        })

    train_results = pd.DataFrame(train_rows)
    test_results = pd.DataFrame(test_rows)
    importances = pd.DataFrame(importance_rows)

    print("\nTraining Performance Table:")
    print(train_results.to_string(index=False))

    print("\nTesting Performance Table:")
    print(test_results.to_string(index=False))

    best_depth = int(test_results.loc[test_results["F1"].idxmax(), "Depth"])
    print(f"\nBest depth based on F1-score: {best_depth}\n")

    best_dt = DecisionTreeClassifier(criterion="gini", max_depth=best_depth, random_state=42)
    best_dt.fit(X_train, y_train)
    y_pred_final = best_dt.predict(X_test)

    print("Confusion Matrix (Best Depth):")
    print(confusion_matrix(y_test, y_pred_final))

    print("\nClassification Report (Best Depth):")
    print(classification_report(y_test, y_pred_final))

    best_fi = dict(zip(feature_names, best_dt.feature_importances_))

    print(f"\nFeature Importance for Depth = {best_depth}:")
    sorted_fi = sorted(best_fi.items(), key=lambda x: x[1], reverse=True)
    fi_df = pd.DataFrame(sorted_fi, columns=["Feature", "Importance"])
    print(fi_df.to_string(index=False))

    return train_results, test_results, importances, best_depth, fi_df

def VisualizeDTResults(train_results, test_results, depths):
    plt.figure(figsize=(6, 4))
    sns.lineplot(x=depths, y=train_results['Accuracy'], marker='o', label="Train Accuracy")
    sns.lineplot(x=depths, y=test_results['Accuracy'], marker='o', label="Test Accuracy")
    plt.title("Decision Tree Accuracy vs Depth")
    plt.xlabel("Max Depth")
    plt.ylabel("Accuracy")
    plt.tight_layout()
    plt.show()

    plt.figure(figsize=(6, 4))
    sns.lineplot(x=depths, y=train_results['F1'], marker='o', label="Train F1")
    sns.lineplot(x=depths, y=test_results['F1'], marker='o', label="Test F1")
    plt.title("Decision Tree F1 Score vs Depth")
    plt.xlabel("Max Depth")
    plt.ylabel("F1 Score")
    plt.tight_layout()
    plt.show()



   